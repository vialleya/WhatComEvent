executer ces commandes avant d'importer le projet dans eclipse
	npm install -g concurrently
	npm install -g lite-server
	npm install -g typescript

	puis dans un cmd
	    cd [chemin vers le projet contenant package.json]
	      tsc --init 	// si tsconfig.json n'est pas pr�sent, 
	      npm -i 		// installe les dependances list�es dans le fichier package.json
	      npm start 	// quand les services seront termines, avant de basculer en mode full js (plus de transpiler)
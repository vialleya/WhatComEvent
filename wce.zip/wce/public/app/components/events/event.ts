export class Event {
  id: number;
  name: string;
  isSecret = false;
}
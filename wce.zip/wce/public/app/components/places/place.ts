export class Place {
  id: number;
  name: string;
  isSecret = false;
}